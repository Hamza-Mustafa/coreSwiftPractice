import UIKit


//String literals
let quotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on
till you come to the end; then stop."
"""
print(quotation)


let singleLineString = "These are the same."
let multilineString = """
These are the same.
"""
print(singleLineString)
print(multilineString)


let lineBreaks = """

This string starts with a line break.
It also ends with a line break.

"""
print(lineBreaks)

let threeMoreDoubleQuotationMarks = #"""
Here are three more double quotes: """
"""#
print(threeMoreDoubleQuotationMarks)

var emptyString = ""               // empty string literal
var anotherEmptyString = String()  // initializer syntax
if anotherEmptyString.isEmpty {
    print("Nothing to see here")
}

//STring Mutability
var variableString = "Horse"
variableString += " and carriage"
print(variableString)
// variableString is now "Horse and carriage"

let constantString = "Highlander"
//constantString += " and another Highlander"
// this reports a compile-time error - a constant string cannot be modified

//Accessing Individual characters from string
for character in "Dog!🐶" {
    print(character)
}

//character to string conversion
let catchar : [Character] = ["c","a","t","🐱"]
let catstr = String(catchar)
print(catstr)


//character appending
var welcome = "Hello There"
let mark : Character = "!"
welcome.append(mark)

//String Interpolation
let multiplier = 3
let message = "\(multiplier) times 2.5 is \(Double(multiplier) * 2.5)"
print(message)

//Count
let countchar = "hey"
countchar.count

//String Indices
let greeting = "Guten Tag!"
greeting[greeting.startIndex]
// G
greeting[greeting.index(before: greeting.endIndex)]
// !
greeting[greeting.index(after: greeting.startIndex)]
// u

//greeting[greeting.index(before: greeting.startIndex)] //error
//greeting[greeting.index(after: greeting.endIndex)] //error
//greeting[greeting.endIndex] // Error

greeting[greeting.index(greeting.startIndex, offsetBy: 0)]
// G
greeting[greeting.index(greeting.startIndex, offsetBy: 9)]
//!
greeting[greeting.index(greeting.endIndex , offsetBy: -10)]
//
greeting.indices

//Indices
let msg = "Qaim Don"
for index in msg.indices {
    print("\(msg[index]) ")
}

for index2 in msg.indices {
    print("\(msg[index2]) ", terminator: "")
}

//Inserting string
var welcome2 = "hello"
welcome2.insert("!", at: welcome2.endIndex)
// welcome now equals "hello!"

welcome2.insert(contentsOf: "there", at: welcome2.endIndex)
// welcome now equals "hello! there"

var welcome3 = "hello!"
welcome3.insert(contentsOf: " there", at: welcome3.index(before: welcome3.endIndex))
// welcome now equals "hello there!"

var welcome4 = "Hello There!"
welcome4.remove(at: welcome4.index(before: welcome4.endIndex))
print(welcome4)
// welcome now equals "Hello There"

let range = welcome4.index(welcome4.endIndex, offsetBy: -6)..<welcome4.endIndex
welcome4.removeSubrange(range)
// welcome now equals "Hello"


var xt2 = [0, 1, 2, 3, 4, 5]
xt2.removeSubrange(3...4)
print("Method 2:", xt2)

//Prefix and Suffix

let romeo = [
    "Act1 : Where are you?",
    "Act1 : At mansion",
    "Act1 : How are you?",
    "Act2 : Fine",
    "Act2 : Do i like you?",
    "Act2 : No, mansion"
            ]
//Prefix
var Act1count = 0
for scenes in romeo {
    if scenes.hasPrefix("Act1")
    {
        Act1count += 1
    }
    
}
print("There are \(Act1count) scenes of Act1")


//Sufix
var Mansioncount = 0
var Youcount = 0
for scenes in romeo {
    if scenes.hasSuffix("mansion")
    {
    Mansioncount += 1
    }
    else if scenes.hasSuffix("you?")
    {
        Youcount += 1
    }
}
print("There are \(Mansioncount) mansion words and \(Youcount) you words.")

