//: Playground - noun: a place where people can play

import UIKit


//Printing variables
var str = "Hello, variable"
print(str)
print("hi hamza")


//constants , fixed value one time decalration
let str2 = "constant"
print(str2)


//Multiple assigning of variables
var(age1, age2, age3) = (10,20,30)
print("value of age1 = \(age1)")
print("value of age2 = \(age2)")
print("value of age3 = \(age3)")


//newline
var newline = "there comes \n newline."
print(newline)

//Conditional Statements

var isRainy = true
if isRainy == true {
    print("Use Umbrella")
}
else{
    print("Wear shots")
}

var age = 10
if age == 10 || age > 10 // Or check either one condition && checks both condition
{
    print("i am true")
}


// Arrays
var items=["biscuit","oranges","burger"]
print(items[2])
items.append("milk") //for adding new array value
items.count //counts items in array
items.first
items.last
items.remove(at: 1) //for deleting value
print(items)

items.removeAll() //for removing all items
print(items)

//Blank Array
var blank=[Int]()
blank.append(5)
blank.append(10)
blank[1] = 20 //updating array
print(blank)

//Dictionaries - look liks arrays
var myDict = ["school":"study" , "mosque":"prayer"]     // [Key:value]
print(myDict)
myDict["school"] //printing one value
myDict["bar"] = "alcohol" //adding new value in dictionary
print(myDict)
myDict.count //counting items
myDict["bar"] = "party" //updating values in dictionary
print(myDict)
myDict.removeValue(forKey: "bar")
print(myDict)
myDict.removeAll() // deleting all items
print(myDict)


//For Looping
print("---------------------Simple Loop---------------------------")
for point in 1...5
{
    print(point)
}

print("---------------------Simple Loop with stride function---------------------------")
for num in stride(from: 20, to: 0, by: -5){ //it will print 20,15,10 .. doing -5 untill 0 reach
    print(num)
}

print("---------------------Simple Loop from array---------------------------")
var shopping = ["food","shots","razor"]
for saman in shopping{
    print(saman)
}

print("---------------------Simple Loop from Dictionary--------------------------")
var myDict2 = ["school":"study" , "mosque":"prayer"]
for items2 in myDict2{
    print(items2)
    print(items2.key)
}

print("---------------------Simple Loop from Enumerated function to get both index and value--------------------------")
for (index,value) in myDict2.enumerated(){
    print(index)
    print(value.key)
    print(value)
}

//While loop
print("---------------------WHile loop--------------------------")
var counter = 0
while counter < 5{
    print(counter)
    counter += 1
}

print("---------------------WHile loop with repeat keyword--------------------------")
var counter2 = 0
repeat{      // in repeat conditon condition checks in end as compare to normal while loops
    print(counter2)
    counter2 += 1
} while counter2 < 5

//Switch
print("---------------------Switch Condition--------------------------")

var ages = 20

switch ages {
case 10:
    print("your age is 10 ")
case 20:
    print("your age is 20 ")
default:
      print("your age is infinity ")
}


//Functions  def:set of statments organized togather for making a path
print("---------------------Functions--------------------------")

func testing(){
    print("hello world")
    print("fuck ios")
}
testing()

print("---------------------Function to add value with parameters --------------------------")

func add(numb1: Int , numb2: Int)
{
    print(numb1 + numb2)
}
add(numb1: 10 , numb2: 10)

print("---------------------Function with return type--------------------------")

func multiply(value11: Int, value12: Int) -> Int {
    return value11 * value12
}
print(multiply(value11: 2 , value12: 2))
//we use return type for savinf its value in a variable like
var final = multiply(value11: 2 , value12: 2)
print("final value is \(final)")


//Structures
//structures are value types
print("---------------------Structures-------------------------")

var name = "hamza mustafa"
var latitude = 10.2
var longitude = 11.3

struct userLocation {
    var name : String
    var latitude : Double
    var longitude : Double
}

var myLoc = userLocation(name: "hamza", latitude: 10.2, longitude: 11.3)
myLoc.latitude
myLoc.longitude
myLoc.name

func getLoc(loc:userLocation)
{
    print(loc.name)
}
getLoc(loc: myLoc)


print("---------------------Classes Sean Allen-------------------------")
//Difference between class and structures

//class example
//class is pass by refrence type
//class can  be inherited
//class is like a google spreadsheet , giving someone rights to edit the original sheet aswell

class MacBook{
    var year: Int
    var color: String
    init(year: Int , color: String) {
        self.year = year
        self.color = color
    }
}//class end

let myMacbook = MacBook(year: 2016, color: "Space Gray")
print(myMacbook.color)
var stolenMacbook = myMacbook

stolenMacbook.color = "Green"
print(stolenMacbook.color)
print(myMacbook.color)



print("---------------------Structures Sean Allen-------------------------")
//Structer example
//in structure we dont need intializers init()
//structure is pass by value type
//structure can not be inherited
//structure is like email copy of spreadsheet , you sent someone to edit but you have the original one as well :D

struct iPhone {
    var number: Int
    var color: String
}

let myiPhone = iPhone(number: 7 , color:"black")
var stoleniPhone = myiPhone

stoleniPhone.color = "Rose"
print(stoleniPhone.color)
print(myiPhone.color)





print("---------------------Enumeration (Enum) first type-------------------------")
//purpose of enum is set of data to classify

enum Direction{
    case North
    case South
    case East
    case West
}

var dir =  Direction.North

switch dir {
case Direction.North:
    print("go forward")
case Direction.South:
    print("go backwards")
case Direction.East:
    print("take a right")
case Direction.West:
    print("take a left")
//default:
//         in enum case default aint allowed because we have set 4 exact cases already
}

print("---------------------Enumeration (Enum) Second Type-------------------------")
//in case if you dont wanna use switch and associate value diretly (raw value)

enum Direction2:String
{
    case North2 = "go forward"
    case South2 = "go backwards"
    case East2 = "take a right"
    case West2 = "take a left"
}
var dir2 =  Direction2.North2
print(dir2.rawValue)


//classes and objects
print("---------------------Classes and objects methods-------------------------")

class Persons{
    var name: String  
    var age: Int
    
    //init function allow us to set properties of instance of a class
    init(name: String , age:Int)
    {
     self.name = name
     self.age = age
    }
    
    func methody(){
        print("My name is \(self.name) and age is \(self.age)")
    }

}
var animals = Persons(name: "mustafa", age: 22)
// here animals is the object instance of class persons
animals.name
animals.age
animals.methody()


//Inheritance and overriding
print("---------------------Inheritance and overriding------------------------")

class Parent{
    func parentMethod(){
        print("this is parent method")
    }
    
    func getOver(){
        print("this is parent over wala method")
    }
}
var p = Parent()
p.parentMethod()

class Child : Parent{
    func childMethod(){
        print("this is child method")
    }
    override func getOver(){
        print("this is child override wala method")
    }
}
var c = Child()
c.childMethod()
c.parentMethod()
c.getOver() // override keyword will override same name method to the child class method


//Protocols get set
print("---------------------Protocols get set------------------------")
//protocols are blueprints of functions and properties that we mention inside the protocol statements
//protocols are used to distinguisg between the two like birds can fly not all can fly like penguins

protocol Fly{
    var weight : Int {get set}  //get means read only , set means update the value , we can use either one or both upto us here
    func fly() -> String  //it should return string we set it
}

class Pigeon : Fly { //assigning protocol to our new class
    var weight =  50
    
    func fly() -> String{
        return "i can fly baby"
    }
} //class

var p2 = Pigeon()
print(p2.fly())
p2.weight = 20 //setting new value
print(p2.weight)


//Extensions
print("---------------------Extensions------------------------")
//funcionality of an existing class,structure or enum can be added with extensions
//overriding of functionalities not possible with extensions

extension Int{
    func plusOne() -> Int {
        return self + 1
    }
}

var numbero = 10
print(numbero.plusOne())
print(numbero)


//mutating extension function
print("---------------------mutating extension function------------------------")

extension Int{
     mutating func plusTwo()  {
        self += 1
    }
}

var numbero2 = 10
print(numbero2.plusTwo())
print(numbero2)


extension Int{
    mutating func square(){
        self *= self
    }
}
numbero.square()
print(numbero)






























