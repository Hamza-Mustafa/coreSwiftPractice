print("------------------CONSTANT TIME ALGO - 0(1)---------------------------")
var array = [1,2,3,4,5]
print(array[3])

print("------------------LINEAR TIME ALGO - 0(n)----------------------------")

var numberList = [10,20,30]
var iterations = 0
func linearSearch(key: Int)
{
    //check all possible values until we find a match
    for number in numberList {
        iterations = iterations + 1
        if (number == key) {
            let results = "value \(key) found"
            print(results)
            print("number of iterations = \(iterations)" )
            break
        }
    }
}
linearSearch(key: 30)

print("------------------Binary Search TIME ALGO - 0(logn)----------------------------")

let numbers = [1, 2, 3, 4, 5, 6]

func binarySearch<T: Comparable>(numbers:[T] , key:T) -> Int? {
    var iter = 0
    var lowerBound = 0
    var upperBound = numbers.count
    
    //print(upperBound) = 6
    
    while lowerBound < upperBound {
        let midIndex = lowerBound + (upperBound - lowerBound) / 2
        if numbers[midIndex] == key {
            print("Binary iterations = \(iter)")
            return midIndex
        } else if numbers[midIndex] < key {
            lowerBound = midIndex + 1
        } else {
            upperBound = midIndex
        }
        iter += 1
    }
    return nil
}
binarySearch(numbers: numbers, key: 5)

