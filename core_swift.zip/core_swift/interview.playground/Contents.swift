//Closures are self-contained blocks of functionality that can be passed around and used in your code.
//Global and nested functions, as introduced in Functions, are actually special cases of closures.
//Closures take one of three forms:
//1-Global functions are closures that have a name and do not capture any values.
//2-Nested functions are closures that have a name and can capture values from their enclosing function.
//3-Closure expressions are unnamed closures written in a lightweight syntax that can capture values from their surrounding context.
//difference b/w closure and func is func has a func name while closure havent
//------------Closure Expression Syntax
//                 { (parameters) -> return type in
//                     statements
//                 }
// https://o7planning.org/en/10577/swift-closures-tutorial
// https://www.programiz.com/swift-programming/closures
// https://learnappmaking.com/closures-swift-how-to/



// some questions:
// What is lazy property in Swift?
// What is didSet and willSet in Swift?
// What is didSet Swift 4?
// What are getters and setters in Swift?
// What is computed property in Swift?
// What's the difference of weak and strong in Swift?
// What is protocol in Swift?
// What is guard in Swift?
// Why we use lazy in Swift?
// What is a static var Swift?
// What is class VAR in Swift?
// What is Autoclosure Swift?

//Properties
//there are of two types of properties in swift
//1.Stored Property
//Stored properties store values (constant or variable) as part of an instance or type
//2.Computed Property
//computed properties don't have a stored value.


//stroed property example
class Circle {
    var radius: Double = 0
}
let circle = Circle()
circle.radius = 10
print("radius: \(circle.radius)") //radius: 10.0

//Property Observers Types ( 1.didSet 2.WillSet )
//In Swift there a two types of property observers: One is called before the new value is assigned and the other one afterwards.

//1-didSet Observer
//The property observer, which is called after the assignment, is marked with the keyword  didSet

class Circle2
{
  var oldvalue = 50.2
  var radius : Double = 0
  { // this useless brace is important
  didSet
    {
     if radius < 0
      {
       radius = oldvalue
      }
    }
  }
}
let circle2 = Circle2()
circle2.radius = -10
print("radius = \(circle2.radius)")
circle2.radius = 20
print("radius = \(circle2.radius)")

//1-WillSet Observer
//The property observer, which is called before the assignment, is marked with the keyword willSet

class Circle3
{
 var newValue = 70
 var radius : Int = 0
 {
   willSet
   {
       print("New assigned value is :\(newValue)")
   }
   didSet
   {
      if radius < 0
      {
       radius = newValue
      }
   }
 }
}

let circle3 = Circle3()
circle3.radius = 40
print("radius = \(circle3.radius)")

//http://www.thomashanning.com/properties-in-swift/

