import UIKit


let possibleNumber = "haha"
let convertedNumber = Int(possibleNumber)
// convertedNumber is inferred to be of type "Int?", or "optional Int"

if let actualNumber = convertedNumber {
    print("The string \(possibleNumber) has an integer value of \(actualNumber)")
} else {
    print("The string \(possibleNumber) could not be converted to an integer")
}
// Prints "The string "123" has an integer value of 123"


//Numeric Type Conversions
let three = 3
let pointOneFourOneFiveNine = 0.14159
let pi = Double(three) + pointOneFourOneFiveNine
let integerPi = Int(pi)

//Type ALiases
typealias AudioSample = UInt16
var minAmplitudeFound = AudioSample.min
var maxAmplitudeFound = AudioSample.max

//Optional Nil
var serverResponseCode: Int? = 404
serverResponseCode = nil

//var code = nil //error


