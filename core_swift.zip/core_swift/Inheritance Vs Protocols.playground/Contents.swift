//Recursive Function
//A function that calls itself is known as a recursive function
//you must create a condition so that the function does not call itself (infinitely).
func recursive(num : Int)
{
  print(num)
  if num>0
  {
  recursive(num : num-1)
  }
}
print(recursive(num:2))

//Inheritance Vs Interfaces=Protocols in Swift

//Simple Inheritance
class Dog{
   func bark()
   {
       print("bark")
   }
}
class GermanShephard : Dog
{
}
let myDog = GermanShephard()
myDog.bark()

//Inheritance is extremely useful for modeling hierarchies like this one

// class Dog2{
//  func bark() {
//  print("bark")
//  }
// }
// class GermanShepard2 : Dog2 {
//   func sinffDrugs() {
//     if drugs(){
//         bark()
//     }
//   }
// }
// class BullDog2 : Dog2 {
//   func sniffDrugs(){
//      if drugs(){
//           bark()
//      }
//   }
// }

//We can optimize our code by doing this data modelling and make a new dog class that can swim

// class Dog2{
//  func bark() {
//  print("bark")
//  }
// }
// class SniffDrugs : Dog2{
//  func sinffDrugs() {
//     if drugs(){
//         bark()
//     }
//   }
// }
// class GermanShepard2 : SniffDrugs {
// }
// class BullDog2 : SniffDrugs {
//      func swim() {
//         print("Splash!")
//     }
// }
// class Poodle: Dog {
//     func swim() {
//         print("Splash!")
//     }
// }
//here poodle and bulldog both can swim but we cant inherit two classes for bulldog2 class at a time
//so the solution is protocols here now
//A protocol in Swift defines methods or properties that a class can then adopt.
//The GermanShephard3 & BullDog3 class both adopt the Barkable protocol,
//meaning they must both provide implementations for bark().

// protocal : Barker{
//   func bark()
// }

// class GermanShephard3 : Barker {
//     func bark() {
//         print("Bark!")
//     }
// }
// class BullDog3 : Barker {
//     func bark() {
//         print("Bark!")
//     }
// }
// class Poddle3 : Barker {
// }

//for removing code duplication we use a default implementation for bark()
//using a protocol extension


protocol Barker5{
  func bark()
}
extension Barker5 {
  func bark() {
        print("Bark!")
    }
}

protocol DrugSniffer5 {
    func sniffDrugs()
}
extension DrugSniffer5 {
    func sniffDrugs() {
        print("I found drugs!");
    }
}

protocol Swimmer5 {
    func swim()
}
extension Swimmer5 {
    func swim() {
        print("Splash!")
    }
}

class GermanShephard5 : Barker5, DrugSniffer5  {
}
class BullDog5 : Barker5, Swimmer5, DrugSniffer5  {
}
class Poddle5 : Barker5, Swimmer5 {
}

let myProtocolDog = BullDog5()
myProtocolDog.bark()
myProtocolDog.sniffDrugs()
myProtocolDog.swim()
