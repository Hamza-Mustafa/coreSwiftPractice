import UIKit

//we can convert any type(string,double,int) into optional type
var age : Int? = nil //for assigning nil we have to use optional

//var age2 = nil  It doesn't know what type of nil it is.

var stringAge = "25"
var intAge = Int(stringAge)
print(intAge) //it will return optional value because 25 string is possible to convert in Int Type
print(intAge!) // ! use for unwrapping if its Int optional turn it into Int Type and so on.

//But what if we give value 25S to stringAge variable
var stringAge2 = "25s"
var intAge2 = Int(stringAge2)
print(intAge2) //it will return nil because 25s can not be converted into Int type thats why swift consider it nil optional type

//print(intAge2!) //thats the crashing point of your app when you trynaa convert an optional into its any respective type but the user inputs more than one type data ,for cop this issue we use (Force unwrapping condition)

//Brute Force Unwrapping
var favCandy : String? = "100 dairy milk"

// Easy Approach
// So basically this condition executes when favCandy is not equals to nil
//this approach will help us to bypass app crashing in case thats nil.
if favCandy != nil {
    print(favCandy!)
}

//Professional Approach
//favCandy is an optional here while favCandyUnwrapped is not optional constant here
//We dont have to unwrapped (!) favCandyUnwrapped here as its non optional
//This condition has exactly same meaning as above condition it will execute only when favCandy isn't nil
if let favCandyUnwrapped = favCandy {
    print(favCandyUnwrapped)
}


/*  Concept of why do we use  ____  as! ____ here:
       let addVc = segue.destination as! AddTodoViewController
       addVc.previosVC = self
*/
//UiTableView inherits UiViewController class

class Animal {
    var name = "BullDog"
    var age = 0
}
class Dog : Animal {
    var furColor = "Brown"
}
class Monkey : Animal{
    var tail = "Long"
}

var someAnimal : Animal = Dog() //Dog class is an instance here
let doggy = someAnimal as! Dog //so here we are forcing it to get data from Dog
print(doggy.furColor)

var otherAnimal : Animal = Monkey()
let doggy2 = otherAnimal as! Dog //it will give us error because we assigned moneky to animal not dog
print(doggy2.furColor)

//to resolve this we use better approach like this
//so this will execute only when dog is assigned
if let doggy2 = otherAnimal as? Dog {
    print(doggy2.furColor)
}





