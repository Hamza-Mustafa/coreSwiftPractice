
//Assignment Op
let b=5
var a=10
a=b
print(a)

//Remainder Op

var a1=9
var b1=4
var c1 = a1%b1
print(c1)


//unary minus op
let three = 3
let minusThree = -three       // minusThree equals -3
let plusThree = -minusThree   // plusThree equals 3, or "minus minus three"

//unary plus op
let minusSix = -6
let alsoMinusSix = +minusSix  // alsoMinusSix equals -6

//compound Assignment op
var p = 1
p += 2 // (p=p+2)

//Tuples Comparision Op
(1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" are not compared
(3, "apple") <= (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
(4, "dog") != (4, "dog")      // false because 4 is equal to 4, and "dog" is equal to "dog"
(5, "cat") == (5,"cati") //false because 5==5 but cat != cati

//ternary conditional op
//If question is true, it evaluates answer1 and returns its value; otherwise, it evaluates answer2 and returns its value.
//question ? answer1 : answer2

let pig = 20
let lion = 100

var biggerAnimal : Bool = true
let result = biggerAnimal ? lion : pig


//nil coalesing op

let  defaultColor = "red"
var myColor: String?
var Color = myColor ?? defaultColor

var yourColor : String? =  "green"
var Color2 = yourColor ?? defaultColor


//Range Operators

//Close Range Operator
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

//Half Range Operator

//E.g 1
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

//E.g 2
let names = ["Anna", "Alex", "Jack"]
let count = names.count
for i in 0..<count {
    print("Person \(i + 1) is called \(names[i])")
}
print("-----------------------------")
//One Sided Range Op
var values : Int?
for values in names[1...] {
    print(values)
}
print("-----------------------------")
var values2 : Int?
for values2 in names[...1] {
    print(values2)
}
print("-----------------------------")

var values3 : Int?
for values3 in names[..<2]
{
    print(values3)
}
print("-----------------------------")

let range = ...5
range.contains(7)   // false
range.contains(4)   // true
range.contains(-1)  // true
range.contains(0)  // true
range.contains(-2)  // true
range.contains(5)  // true

//Logical Op
//Not Op
let allowedEntry = false
if !allowedEntry
{
    print("Access Denied")
}
print("-----------------------------")
//And Op
let DoorCode = true
let Scan = false
if DoorCode && Scan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

print("-----------------------------")

let hasDoorKey = true
let knowsPassword = true
if hasDoorKey || knowsPassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
