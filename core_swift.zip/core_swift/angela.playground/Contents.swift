import UIKit

var myAge : Int = 23
let myname1 : String = "Hamza"
let nmyname2 : String = "Mustafa"


let myfullname = myname1 + nmyname2

//let error = myAge + myname1 // explicit datatype error

let myfullname2 = "\(myname1) mustafa"
let mydetail = "\(myAge)  hamza"
let mydetails2 = "\(myAge)  \(myname1)  \(nmyname2)"

let chara : Character = "c"
/////////////////////


var Name : String? = nil
if Name != nil
{
    print(Name)
}
else
{
    print("Name has no value")
}

///unwrapping

var car : String?
car = "BMW"
print(car)
print(car!)


//automatic un wrapping

var name2 : String!
name2 = "ali"
print(name2!)

//optional binding

var optvar : String?
optvar = "value exists"

if let checkValue = optvar {
    print("Our optional variable have \(optvar)")
}
else{
    print("Our optional variable have no value")
}
