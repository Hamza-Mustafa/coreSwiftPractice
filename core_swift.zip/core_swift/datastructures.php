`https://www.raywenderlich.com/990-swift-algorithm-club-swift-binary-search-tree-data-structure


Elementary Data Structures
--------------------------------
stack
queue
Link List
sorting algorithms
merge sort


Trees
--------------------
binary tree
binary search
Heap
Heap Sort
Priority Queue


Graphs
-----------------
Graph Components
Adjacency List
Dijkstra's Algorithm
Prim's Algorithm


Types of Complexity
--------------------
1-Time Complexity 
    [time required to run an algo as the input size increases]
2-Space Complextiy
    [measure of the memory needed for an algo to run]


Big O Notation (it's used to represent different types of time complexity)

+)Different Magnitudes of time complexity
   
   1-Constant Time Algo
   [An algorithm is said to be constant time (also written as O(1) time) if the value of T(n) is bounded by a value that does not depend on the size of the input] [For example, accessing any single element in an array takes constant time as only one operation has to be performed to locate it.]
   [# Look-up table (on average)]

ANALOGY : (if I had a deck of cards, and I asked you to remove the first any card at random, you could simply grab a card from the deck without having to search through the entire deck. That is a constant time look-up.)


   2-Quadratic Time Algo O(N²)
   [Quadratic Time Complexity represents an algorithm whose performance is directly proportional to the squared size of the input data set.. In doing so, we are passing over the same array twice with each search, producing a Quadratic Time Complexity.]
   [ Sorting array with bubble sort ]

ANALOGY : (Let’s say you picked the first card in the deck, and how to remove all the cards with that same number. You would have to search through the deck, removing the duplicates at every point. Once you were sure that all the duplicates were removed, you’d continue doing the same thing for second card, and third, and so on until you reached the end of the deck. This is an example of Quadratic Time Complexity.)   


   3-Linear Time Algo
   [Linear time complexity O(n) means that as the input grows, the algorithms take proportionally longer to complete.]
   [# Find max element in unsorted array,
   # Duplicate elements in array with Hash Map]

ANALOGY : (If I had a deck of cards and I wanted you to select a specific card (let’s say the 10❤s). You would have to look through every card until you found that card. Sure, there’s a possibility that it would be the first card in the deck, but that’s highly unlikely. Now think about if the deck of cards were filled with hundreds of other cards non-10❤ cards. Your search is directly related to how large the deck of cards is. That is an example of Linear Complexity.)

   4-Logarithmic Time Algo
   [Logarithmic running time ( O(log n) ) essentially means that the running time grows in proportion to the logarithm of the input size ]
   [#Finding element on sorted array with binary search]

ANALOGY : (let’s say our cards are ordered from increasing to decreasing order, with the deck split in half, one pile containing the clubs and spades, the other containing the hearts and diamond cards. Now, if I asked you to pull out the 10❤s, you could safely conclude that the card should be in the second pile, since that’s where the diamonds and hearts cards are. Furthermore, you know that the card should only be with the hearts, so you split the deck to only search through the heart cards. Since you’ll be searching for the 10❤s, you can safely assume that the bottom half of the deck is irrelevant (since they deck is already sorted). You can continue to split the remaining cards until you eventually find the 10❤s. You didn’t have to search through every card to find it, but it also wasn’t as easy as simply grabbing a random card. That is an example of Logarithmic Time Complexity)


   5-Exponential Time Algo : O(2n)
   [Exponential Time complexity denotes an algorithm whose growth doubles with each additon to the input data set]
   [# Find all subsets]

   6-Cubic Time Algo : O(n3)
   [if the running time of the three loops is proportional to the cube of N. When N triples, the running time increases by N * N * N.]
   [#3 variables equation solver]

   7-Factorial Time Algo : O(n!)
   [# Find all permutations of a given set/string]

   8-Linearithmic Time Algo : O(n log n)
   [They are capable of good performance with very large data sets. Some examples of linearithmic algorithms are: heapsort. merge sort.]
   [# Sorting elements in array with merge sort]

