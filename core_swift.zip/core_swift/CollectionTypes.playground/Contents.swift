import UIKit

// Arrays
var items=["biscuit","oranges","burger"]
print(items[2])
items.append("milk") //for adding new array value
items.count //counts items in array
items.first
items.last
items.insert("Syrup", at: 0) //for inserting value
items.remove(at:1) //for deleting value
print(items)

items.removeAll() //for removing all items
print(items)

//Blank Array
var blank=[Int]()
blank.append(5)
blank.append(10)
print(blank)
blank[1] = 20 //updating array
print(blank)

//Iterarin Array Values
for item in blank {
    print(item)
}

//For Accessing value along with its index use enumerated()
for (index, value) in blank.enumerated() {
    print("Item \(index + 1): \(value)")
}

//deafult value array
var values = Array(repeating: "A", count: 3)
print(values)


//Dictionaries - look liks arrays
var myDict = ["school":"study" , "mosque":"prayer"]     // [Key:value]
print(myDict)
myDict["school"] //printing one value
myDict["bar"] = "alcohol" //adding new value in dictionary
print(myDict)
myDict.count //counting items
myDict["bar"] = "party" //updating values in dictionary
print(myDict)
myDict.removeValue(forKey: "bar")
print(myDict)
myDict.removeAll() // deleting all items
print(myDict)

//Sets
//Empty Set
var letters = Set<Character>()
print(letters.count)

letters.insert("a")
// letters now contains 1 value of type Character
print(letters)
letters = []
print(letters)
// letters is now an empty set, but is still of type Set<Character>




//--------------- SET --------------

var Genres : Set = ["Rock","Hip Hop","Pop"]

print(Genres.count)

if Genres.isEmpty {
    print("Set is Empty.")
} else {
    print("Set is not Empty")
}
/////////
if Genres.contains("Rock") {
    print("Rock is present.")
} else {
    print("Rock is not present")
}
/////////
Genres.remove("Rock")
print(Genres)
////////
Genres.insert("Classical")
print(Genres)

//Iterating Over a Set

for values in Genres
{
    print(values)
}

//sorted way Ascending Order
let students: Set = ["B", "A", "C", "E", "D"]
let sortedStudents = students.sorted()
print(sortedStudents)

//Sorted:By Descending Order
let teachers: Set = ["B", "A", "C", "E", "D"]
let sortedteachers = teachers.sorted(by: >)
print(sortedteachers)

//reverse function (Reverses the elements of the collection in place)
var characters: [Character] = ["C", "a", "f", "é"]
characters.reverse()
print(characters)
// Prints "["é", "f", "a", "C"]

//reversed() - Returns a view presenting the elements of the
// collection in reverse order.
let word = "Backwards"
for char in word.reversed() {
    print(char, terminator: "")
}
print("");
let reversedWord = String(word.reversed())
print(reversedWord)

//Shuffle reorders the elements of array and not returns something,
//but Shuffled does the samething but returns the shuffled array:
//shuffle
//Use the shuffle() method to randomly reorder the elements of an array.
var numbers = [1, 2, 3, 4]
numbers.shuffle()
print(numbers)

//shuffled() Returns the elements of the sequence
let x = [1, 2, 3].shuffled()
print(x)

//swapAt
var names = ["Paul", "John", "Ali", "Zx"]
names.swapAt(0, 1)
print(names)

//partition(by:)
var num = [5, 8, 2, 3, 5, 6, 1]
let p = num.partition(by: { $0 > 5 })
print(p)
print(num)



