//Functions with return types
func greet(person:String) -> String
{
  let name = "hamza " + person
  return name
}
print(greet(person:"mustafa"))

//Function without parameters
func without() -> String
{
return "Without parameters"
}
print(without())

//Function With Multiple parameters
func bottle(expiry:Int , fresh:Bool) -> String
{
  if fresh
  {
  return "water is fresh"
  }
  else
  {
  return "water is not fresh"
  }
}
print(bottle(expiry:2019 , fresh:false))

//Function Without Return Values
func noreturn(age:Int)
{
 print("No return values \(age)")
}
print(noreturn(age:24))

//Ignored Return Value Function
//The first function, printAndCount(string:), prints a string, and then returns its
//character count as an Int. The second function, printWithoutCounting(string:),
//calls the first function, but ignores its return value. When the second function
//is called, the message is still printed by the first function, but the returned value is not used.
    func printAndCount(string: String) -> Int {
        print(string)
        return string.count
    }
    func printWithoutCounting(string: String) {
        let _ = printAndCount(string: string)
    }
    printAndCount(string: "hello, world")
    // prints "hello, world" and returns a value of 12
    printWithoutCounting(string: "hello, world")
    // prints "hello, world" but does not return a value

// finds the smallest and largest numbers in an array
//We can use tuple type as the return type for a function to return multiple values
//Functions with Multiple Return Values
    func minMax(array :[Int]) -> (min:Int , max:Int)
    {
     var currentMin = array[0]
     var currentMax = array[0]
      for value in array[1..<array.count]
      {
       if value < currentMin
       {
        currentMin = value
       }
       else
       {
        currentMax = value
       }
      }
      return(currentMin , currentMax)
    }
    let bounds = minMax(array : [1,2,3,4,5,-10])
    print("Min = \(bounds.min) and  Max = \(bounds.max)")

//optional binding with Multiple Return Values
    func minMax1(array: [Int]) -> (min: Int, max: Int)? {
        if array.isEmpty { return nil }
        var currentMin = array[0]
        var currentMax = array[0]
        for value in array[1..<array.count] {
            if value < currentMin {
                currentMin = value
            } else if value > currentMax {
                currentMax = value
            }
        }
        return (currentMin, currentMax)
    }
    let bounds1 = minMax1(array : [1,2,3,4,5,-10])
    print("Min = \(bounds1!.min) and  Max = \(bounds1!.max)")

//Functions With an Implicit Return
func implicitreturn (people : String) -> String
{
  "Hello" + people + "!"
}
print(implicitreturn(people : " implicit"))

func withoutimplict (people2 : String) -> String
{
 return "Hello" + people2 + "!"
}
print(withoutimplict(people2 : " without Implicit"))

//Function Argument Labels and Parameter Names
//here for = argumentLabel
//and  person = parameterName
func anotherGreeting(for person: String) -> String {
    return "Hello, " + person + "!"
}
print(anotherGreeting(for: "argumentLabel"))

//Omitting Argument Labels
// If a parameter has an argument label,
// the argument must be labeled when you call the function.
    func someFunction(_ firstParameterName: Int, secondParameterName: Int)
    {
      print(firstParameterName + secondParameterName)
    }
   print(someFunction(1,secondParameterName: 2))

//Default Parameter Values
    func someFunction(parameterWithoutDefault: Int, parameterWithDefault: Int = 12) {
        // If you omit the second argument when calling this function, then
        // the value of parameterWithDefault is 12 inside the function body.
        print("first para value = \(parameterWithoutDefault) , second para value = \(parameterWithDefault)" )
    }
print(someFunction(parameterWithoutDefault: 3, parameterWithDefault: 6)) // parameterWithDefault is 6
print(someFunction(parameterWithoutDefault: 4)) // parameterWithDefault is 12

//Variadic Parameters
//its use for passing zero or more values of a same type for a single parameter name
//Use (...) after the parameter’s type name with variadic parameter.
//A function may have at most only one variadic parameter.
    func arithmeticMean(_ numbers: Double...) -> Double {
        var total: Double = 0
        for number in numbers {
            total += number
        }
        return total / Double(numbers.count)
    }
    print(arithmeticMean(1, 2, 3, 4, 5))
    // returns 3.0, which is the arithmetic mean of these five numbers
    print(arithmeticMean(3, 8.25, 18.75))
    // returns 10.0, which is the arithmetic mean of these three numbers

//In-Out Parameters
//If you want a function to modify its parameter’s value inside its body use it
//write an in-out parameter by placing the inout keyword right before a parameter’s type
//You can only pass a variable as the argument for an in-out parameter
//You cannot pass a constant or a literal value as the argument,because it cannot be modified
//In-out parameters cannot have default values, and variadic parameters cannot be marked as inout.

    func swapTwoInts(_ a: inout Int, _ b: inout Int) {
        let temporaryA = a
        a = b
        b = temporaryA
    }
var someInt = 3
var anotherInt = 107
swapTwoInts(&someInt, &anotherInt)
print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")

//Function Types
//Define a variable called mathFunction, which has a type of ‘a function that takes two Int values,
//and returns an Int value.’ Set this new variable to refer to the function called addTwoInts.
//The addTwoInts(_:_:) function has the same type as the mathFunction variable,
//and so this assignment is allowed by Swift’s type-checker.

func addTwoInts(_ a: Int, _ b: Int) -> Int {
    return a + b
}
var mathFunction: (Int, Int) -> Int = addTwoInts
print("Result: \(mathFunction(2, 3))")

//Void Function Type
//The type of this function is () -> Void, or “a function that has no parameters, and returns Void.”
    func printHelloWorld() {
        print("Void Function Type")
    }

//Nested Functions
func chooseStepFunction(backward: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int { return input + 1 }
    func stepBackward(input: Int) -> Int { return input - 1 }
    return backward ? stepBackward : stepForward
}
